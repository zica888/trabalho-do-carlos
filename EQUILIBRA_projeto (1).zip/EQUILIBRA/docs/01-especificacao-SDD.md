# €QUILIBRA — Especificação do projeto (SDD)

## 1. Visão e missão
O €QUILIBRA é uma aplicação web educativa de gestão de despesas pessoais. Sua missão é ajudar estudantes e outras pessoas a registrar receitas e despesas, visualizar o saldo mensal e compreender melhor seus hábitos financeiros.

## 2. Problema
Gastos pequenos e recorrentes podem passar despercebidos quando não são registrados. Sem uma visão organizada das entradas e saídas, torna-se mais difícil planejar o uso do dinheiro.

## 3. Público-alvo
Estudantes do Ensino Médio e pessoas que desejam começar a organizar suas finanças pessoais sem depender de ferramentas complexas.

## 4. Objetivos
- Registrar receitas e despesas com data, categoria, descrição e valor.
- Consultar os lançamentos de um mês.
- Calcular automaticamente receitas, despesas e saldo do período.
- Permitir corrigir ou excluir registros.
- Apresentar despesas agrupadas por categoria para apoiar a reflexão sobre hábitos de consumo.

## 5. Tecnologias e justificativas
- **HTML5:** estrutura semântica das páginas.
- **CSS3:** layout responsivo e identidade visual minimalista.
- **JavaScript:** validações imediatas e interação dos campos.
- **PHP 8:** processamento no servidor e regras de negócio.
- **MySQL/MariaDB:** persistência dos lançamentos.
- **PDO:** conexão com banco e consultas preparadas para reduzir risco de SQL injection.

## 6. Escopo do MVP
### Incluído
1. Painel mensal com resumo de receitas, despesas, saldo e quantidade de registros.
2. Cadastro de receita/despesa.
3. Consulta por mês.
4. Edição de lançamento.
5. Exclusão com confirmação.
6. Resumo de despesas por categoria.
7. Validação de campos no frontend e backend.
8. Persistência no banco relacional.
9. Simulador educativo de investimento com capital inicial, taxa de juros, periodicidade, juros simples/compostos, seleção de descontos e prazo em meses.
10. Estimativa do valor líquido e da data de liquidez/vencimento.

### Fora do MVP
- Login e múltiplos perfis.
- Integração com bancos reais ou cartões.
- Importação automática de extratos.
- Orçamentos avançados, notificações e exportação para planilhas.
- Aplicativo móvel nativo.

## 7. Regras de negócio
- Cada lançamento possui exatamente um tipo: `receita` ou `despesa`.
- Descrição é obrigatória e tem no máximo 120 caracteres.
- Categoria deve pertencer à lista oferecida pelo sistema.
- Valor deve ser numérico e maior que zero.
- Data deve ser válida.
- O saldo do mês é calculado por `soma das receitas - soma das despesas`.
- O resumo considera apenas o mês selecionado.
- A exclusão só ocorre por envio POST e exige confirmação no navegador.

## 8. Critérios de aceitação
- CA01: ao abrir o painel, os indicadores mostram os totais reais do mês selecionado.
- CA02: um lançamento válido é gravado no MySQL e aparece na lista.
- CA03: valores zero/negativos, descrição vazia e data inválida são rejeitados.
- CA04: o filtro de mês mostra somente registros daquele mês.
- CA05: a edição persiste os novos dados.
- CA06: a exclusão remove o registro e atualiza o painel.
- CA07: o saldo corresponde às receitas menos as despesas.
- CA08: a página pode ser usada em telas estreitas sem exigir rolagem horizontal do layout geral.
- CA09: entradas do usuário são escapadas ao serem exibidas e os comandos SQL usam parâmetros.
- CA10: o simulador calcula o rendimento bruto e desconta apenas os encargos selecionados pelo usuário.
- CA11: o simulador pergunta prazo e data inicial e mostra a data estimada de liquidez, deixando claro que a liquidez real depende do produto.
