# Roteiro de demonstração — €QUILIBRA

1. **Apresentar o problema:** explicar que gastos cotidianos podem ficar difíceis de acompanhar sem registro.
2. **Apresentar o público:** estudantes e pessoas iniciando a organização financeira.
3. **Mostrar a identidade:** nome €QUILIBRA, marca minimalista e proposta “Suas finanças, em equilíbrio”.
4. **Demonstrar o painel:** saldo, receitas, despesas e quantidade de lançamentos.
5. **Cadastrar uma despesa:** por exemplo, “Livro”, categoria Educação, valor R$ 45,90 e data atual.
6. **Cadastrar uma receita:** por exemplo, “Trabalho eventual”, categoria Renda, valor R$ 150,00.
7. **Demonstrar edição e exclusão:** editar um registro e excluir outro, explicando que o sistema pede confirmação.
8. **Mostrar o filtro mensal:** selecionar outro mês e explicar que os totais são recalculados.
9. **Demonstrar o simulador:** informar capital, taxa e prazo; selecionar somente os descontos aplicáveis; comparar o valor bruto e líquido e mostrar a data estimada de liquidez.
10. **Explicar a implementação:** HTML/CSS/JavaScript no frontend; PHP no backend; MySQL para persistência; PDO e consultas preparadas.
11. **Apresentar testes:** mostrar os casos executados e evidências reais.
12. **Reconhecer limites e próximos passos:** autenticação, orçamento por categoria, exportação CSV e gráficos mais detalhados poderiam entrar em versões futuras.

## Resumo de 30 segundos
“O €QUILIBRA é um gestor de despesas pessoais criado para ajudar estudantes a visualizar para onde o dinheiro está indo. O sistema permite cadastrar receitas e despesas, filtrar lançamentos por mês, editar e excluir registros, acompanhar saldo e gastos por categoria e simular o retorno líquido de um investimento com descontos selecionáveis. A aplicação usa PHP no backend e MySQL para persistir os dados, com validações e consultas preparadas.”
