# Modelagem do banco — €QUILIBRA

## Entidade: `lancamentos`
| Campo | Tipo | Restrições | Finalidade |
|---|---|---|---|
| `id` | INT UNSIGNED | PK, auto incremento | Identificador único |
| `tipo` | ENUM | obrigatório | Receita ou despesa |
| `descricao` | VARCHAR(120) | obrigatório | Nome do lançamento |
| `categoria` | VARCHAR(60) | obrigatório | Classificação financeira |
| `valor` | DECIMAL(10,2) | maior que zero | Valor monetário |
| `data_lancamento` | DATE | obrigatório | Data da movimentação |
| `criado_em` | TIMESTAMP | padrão atual | Data de criação |
| `atualizado_em` | TIMESTAMP | atualiza automaticamente | Última alteração |

## Relacionamentos
O MVP utiliza uma única tabela, portanto não há relacionamentos entre tabelas nesta versão. Uma futura versão multiusuário deverá adicionar uma tabela de usuários e uma chave estrangeira `usuario_id` para garantir isolamento dos dados.

## Consultas principais
- Totais mensais: `SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END)` e equivalente para despesas.
- Saldo: receitas menos despesas.
- Agrupamento: despesas agrupadas por `categoria`.
- Listagem: registros filtrados por intervalo de datas e ordenados da data mais recente para a mais antiga.
