# Planejamento, etapas e testes — €QUILIBRA

## Etapas de desenvolvimento
1. **Definição:** identificar problema, público-alvo, objetivos e limites do MVP.
2. **Modelagem:** definir tabela `lancamentos`, campos, tipos e regras de integridade.
3. **Estrutura inicial:** configurar PHP, conexão PDO e estilos base.
4. **Leitura:** criar painel, cálculo de totais, filtro mensal e resumo por categoria.
5. **Escrita:** implementar cadastro, edição e exclusão.
6. **Validação e segurança:** validar entradas no servidor, escapar saídas e usar consultas preparadas.
7. **Testes:** executar os casos abaixo no ambiente local.
8. **Simulador:** implementar cálculo de juros e descontos selecionáveis, prazo e data estimada de liquidez.
9. **Revisão e apresentação:** corrigir falhas, registrar evidências e demonstrar o MVP.

## Plano de testes
| ID | Cenário | Procedimento | Resultado esperado |
|---|---|---|---|
| T01 | Abertura do painel | Acessar `public/` após configurar o banco | Painel abre sem erro e mostra indicadores |
| T02 | Cadastro de despesa | Registrar “Lanche”, Alimentação, R$ 15,50 e data válida | Registro aparece no mês correto |
| T03 | Cadastro de receita | Registrar receita de R$ 100,00 | Receita é somada ao total de receitas |
| T04 | Validação de valor | Tentar salvar valor 0 ou negativo | Sistema rejeita o lançamento |
| T05 | Validação de descrição | Enviar descrição vazia | Sistema informa erro e não grava |
| T06 | Filtro mensal | Selecionar outro mês | Lista e totais mudam para o período escolhido |
| T07 | Edição | Alterar valor/categoria de um lançamento | Alterações persistem após recarregar |
| T08 | Exclusão | Excluir registro e confirmar | Registro deixa de aparecer |
| T09 | Cálculo do saldo | Registrar receita de 100 e despesa de 30 no mesmo mês | Saldo aumenta em R$ 70,00 |
| T10 | Categoria | Criar despesas em categorias distintas | Resumo agrupa os valores por categoria |
| T11 | Consulta SQL segura | Inserir texto com aspas na descrição | Texto é tratado como dado, sem quebrar SQL |
| T12 | Responsividade | Abrir em janela estreita/celular | Layout se adapta; tabela pode rolar dentro do painel |
| T13 | Simulação básica | Capital R$ 1.000, taxa mensal 1%, 12 meses, juros compostos e sem descontos | Calcula o valor bruto esperado e mantém descontos em zero |
| T14 | Descontos selecionados | Marcar IR de 15% e deixar outros descontos desmarcados | Somente o IR informado é descontado do rendimento bruto |
| T15 | Prazo e liquidez | Informar data inicial e prazo de 6 meses | Exibe data estimada seis meses após a data inicial |
| T16 | Dados inválidos no simulador | Informar capital zero ou prazo menor que 1 | Simulador solicita correção e não calcula |

## Evidências a reunir antes da entrega
- Captura do painel com dados demonstrativos.
- Captura do formulário de novo lançamento.
- Captura após edição e após exclusão.
- Captura da tabela `lancamentos` no MySQL.
- Registro de cada teste como **Aprovado** ou **Reprovado**, anotando qualquer correção feita.

> Importante: os testes estão planejados, mas devem ser executados no ambiente do aluno. Não declare que todos passaram antes de verificar.
