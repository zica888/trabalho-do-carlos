CREATE DATABASE IF NOT EXISTS equilibra
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE equilibra;

CREATE TABLE IF NOT EXISTS lancamentos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('receita', 'despesa') NOT NULL,
    descricao VARCHAR(120) NOT NULL,
    categoria VARCHAR(60) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    data_lancamento DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_data (data_lancamento),
    INDEX idx_tipo (tipo),
    CONSTRAINT chk_valor_positivo CHECK (valor > 0)
);

-- Dados demonstrativos opcionais (remova se preferir iniciar vazio).
INSERT INTO lancamentos (tipo, descricao, categoria, valor, data_lancamento) VALUES
('receita', 'Mesada / renda', 'Renda', 850.00, CURDATE()),
('despesa', 'Mercado', 'Alimentação', 125.50, CURDATE()),
('despesa', 'Transporte', 'Transporte', 48.00, CURDATE());
