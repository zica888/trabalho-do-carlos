# €QUILIBRA — Gestor de Despesas Pessoais

Aplicação web escolar para registrar receitas e despesas, organizar lançamentos por categoria e acompanhar o saldo mensal. Projeto desenvolvido com PHP, MySQL, HTML, CSS e JavaScript.

## Requisitos
- PHP 8.1+ com extensão PDO MySQL
- MySQL 8+ ou MariaDB
- Apache (por exemplo, XAMPP) ou servidor PHP local

## Como executar localmente
1. Copie a pasta `EQUILIBRA` para a pasta pública do servidor (por exemplo, `htdocs` no XAMPP).
2. Importe `database/schema.sql` no phpMyAdmin ou execute-o no MySQL.
3. Abra `config/database.php` e confira host, banco, usuário e senha.
4. Acesse `http://localhost/EQUILIBRA/public/`.
5. O sistema cria/usa os lançamentos do banco. Não há login nesta versão MVP; use apenas dados fictícios em demonstrações escolares.

## Funcionalidades do MVP
- Dashboard com saldo do mês, receitas, despesas e total de lançamentos.
- Cadastro de receita ou despesa com descrição, valor, categoria e data.
- Consulta dos lançamentos e filtro por mês.
- Edição e exclusão de lançamentos.
- Resumo visual de despesas por categoria e validação no navegador/servidor.
- Simulador educativo de investimento com capital inicial, taxa, periodicidade, capitalização, descontos selecionáveis e prazo.
- Estimativa de valor líquido e data de liquidez calculada pelo prazo informado.
- Persistência em MySQL via PDO e consultas preparadas.

## Estrutura
- `public/`: páginas e recursos públicos.
- `src/`: lógica de acesso a dados e funções auxiliares.
- `config/`: conexão com o banco.
- `database/schema.sql`: estrutura do banco.
- `docs/`: especificação SDD, planejamento, testes e documentação.

## Simulador de investimentos
Acesse `public/simulador.php` pelo link no cabeçalho. O simulador permite selecionar quais descontos se aplicam e informar a porcentagem. As bases de cálculo são simplificadas para fins educativos. A data exibida é uma estimativa de vencimento (data inicial + prazo), não uma confirmação de liquidez de um produto financeiro específico.

## Limitações conhecidas
- Não implementa autenticação, contas bancárias reais, importação de extratos nem aconselhamento financeiro.
- A aplicação é uma ferramenta educativa de organização pessoal. Para uso com várias pessoas, implemente autenticação e isolamento dos dados antes de publicar.
