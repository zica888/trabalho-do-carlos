<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../src/helpers.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: null;
$editando = $id !== null;
$dados = ['tipo'=>'despesa','descricao'=>'','categoria'=>'Outros','valor'=>'','data_lancamento'=>date('Y-m-d')];
$erros = [];

if ($editando) {
    $stmt = $pdo->prepare('SELECT * FROM lancamentos WHERE id = ?');
    $stmt->execute([$id]);
    $registro = $stmt->fetch();
    if (!$registro) { http_response_code(404); exit('Lançamento não encontrado. <a href="index.php">Voltar</a>'); }
    $dados = $registro;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dados = [
        'tipo' => (string)($_POST['tipo'] ?? ''),
        'descricao' => trim((string)($_POST['descricao'] ?? '')),
        'categoria' => (string)($_POST['categoria'] ?? ''),
        'valor' => str_replace(',', '.', (string)($_POST['valor'] ?? '')),
        'data_lancamento' => (string)($_POST['data_lancamento'] ?? '')
    ];
    $erros = validarLancamento($dados);
    if (!$erros) {
        if ($editando) {
            $stmt = $pdo->prepare('UPDATE lancamentos SET tipo=?, descricao=?, categoria=?, valor=?, data_lancamento=? WHERE id=?');
            $stmt->execute([$dados['tipo'],$dados['descricao'],$dados['categoria'],$dados['valor'],$dados['data_lancamento'],$id]);
            $_SESSION['flash'] = 'Lançamento atualizado com sucesso.';
        } else {
            $stmt = $pdo->prepare('INSERT INTO lancamentos (tipo, descricao, categoria, valor, data_lancamento) VALUES (?,?,?,?,?)');
            $stmt->execute([$dados['tipo'],$dados['descricao'],$dados['categoria'],$dados['valor'],$dados['data_lancamento']]);
            $_SESSION['flash'] = 'Lançamento cadastrado com sucesso.';
        }
        header('Location: index.php?mes=' . substr($dados['data_lancamento'],0,7)); exit;
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= $editando?'Editar':'Novo' ?> lançamento | €QUILIBRA</title><link rel="stylesheet" href="assets/style.css"></head>
<body><header class="topbar"><a class="brand" href="index.php"><span class="brand-symbol">€</span>QUILIBRA</a><span class="tagline">Suas finanças, em equilíbrio.</span></header>
<main class="form-container"><a class="back-link" href="index.php">← Voltar ao painel</a><section class="panel form-panel"><p class="eyebrow">CONTROLE FINANCEIRO</p><h1><?= $editando?'Editar lançamento':'Adicionar lançamento' ?></h1><p class="muted">Preencha os dados abaixo. Os campos com * são obrigatórios.</p>
<?php if ($erros): ?><div class="error-box"><strong>Confira os campos:</strong><ul><?php foreach($erros as $erro): ?><li><?= e($erro) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" id="entry-form" novalidate>
<div class="form-grid">
<div class="field full"><label>Tipo *</label><div class="type-options">
<label class="choice <?= $dados['tipo']==='despesa'?'selected':'' ?>"><input type="radio" name="tipo" value="despesa" <?= $dados['tipo']==='despesa'?'checked':'' ?>> − Despesa</label>
<label class="choice <?= $dados['tipo']==='receita'?'selected':'' ?>"><input type="radio" name="tipo" value="receita" <?= $dados['tipo']==='receita'?'checked':'' ?>> + Receita</label></div></div>
<div class="field full"><label for="descricao">Descrição *</label><input id="descricao" name="descricao" maxlength="120" required value="<?= e((string)$dados['descricao']) ?>" placeholder="Ex.: compra no mercado"></div>
<div class="field"><label for="valor">Valor (R$) *</label><input id="valor" name="valor" type="number" min="0.01" max="99999999" step="0.01" required value="<?= e((string)$dados['valor']) ?>" placeholder="0,00"></div>
<div class="field"><label for="data_lancamento">Data *</label><input id="data_lancamento" name="data_lancamento" type="date" required value="<?= e((string)$dados['data_lancamento']) ?>"></div>
<div class="field full"><label for="categoria">Categoria *</label><select id="categoria" name="categoria" required><?php foreach(categorias() as $cat): ?><option value="<?= e($cat) ?>" <?= $dados['categoria']===$cat?'selected':'' ?>><?= e($cat) ?></option><?php endforeach; ?></select></div>
</div><div class="form-actions"><a class="btn btn-light" href="index.php">Cancelar</a><button class="btn btn-green" type="submit"><?= $editando?'Salvar alterações':'Salvar lançamento' ?></button></div>
</form></section><footer>€QUILIBRA · Organização financeira simples e consciente.</footer></main><script src="assets/app.js"></script></body></html>
