<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !$id) {
    http_response_code(400); exit('Requisição inválida.');
}
$stmt = $pdo->prepare('DELETE FROM lancamentos WHERE id = ?');
$stmt->execute([$id]);
$_SESSION['flash'] = $stmt->rowCount() ? 'Lançamento excluído.' : 'Lançamento não encontrado.';
header('Location: index.php'); exit;
