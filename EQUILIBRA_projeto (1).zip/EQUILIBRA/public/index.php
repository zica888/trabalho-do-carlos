<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../src/helpers.php';

$mes = (string)($_GET['mes'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $mes)) $mes = date('Y-m');
$inicio = $mes . '-01';
$fim = date('Y-m-t', strtotime($inicio));
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$stmt = $pdo->prepare("SELECT
    COALESCE(SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END),0) receitas,
    COALESCE(SUM(CASE WHEN tipo='despesa' THEN valor ELSE 0 END),0) despesas,
    COUNT(*) quantidade
    FROM lancamentos WHERE data_lancamento BETWEEN ? AND ?");
$stmt->execute([$inicio, $fim]);
$resumo = $stmt->fetch();
$saldo = (float)$resumo['receitas'] - (float)$resumo['despesas'];

$stmt = $pdo->prepare("SELECT categoria, SUM(valor) total FROM lancamentos
    WHERE tipo='despesa' AND data_lancamento BETWEEN ? AND ?
    GROUP BY categoria ORDER BY total DESC");
$stmt->execute([$inicio, $fim]);
$categoriasResumo = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM lancamentos WHERE data_lancamento BETWEEN ? AND ?
    ORDER BY data_lancamento DESC, id DESC");
$stmt->execute([$inicio, $fim]);
$lancamentos = $stmt->fetchAll();

$maxCategoria = 1;
foreach ($categoriasResumo as $item) $maxCategoria = max($maxCategoria, (float)$item['total']);
$mesLegivel = date('m/Y', strtotime($inicio));
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>€QUILIBRA | Gestor de despesas</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="index.php" aria-label="Equilibra início"><span class="brand-symbol">€</span>QUILIBRA</a>
  <nav class="nav-links"><a class="active" href="index.php">Painel financeiro</a><a href="simulador.php">Simulador</a></nav><span class="tagline">Suas finanças, em equilíbrio.</span>
</header>
<main class="container">
  <section class="welcome">
    <div><p class="eyebrow">VISÃO GERAL</p><h1>Seu dinheiro, sob controle.</h1><p class="muted">Acompanhe entradas e saídas e tome decisões com mais clareza.</p></div>
    <form class="month-filter" method="get">
      <label for="mes">Mês de referência</label>
      <input id="mes" type="month" name="mes" value="<?= e($mes) ?>">
      <button class="btn btn-dark" type="submit">Filtrar</button>
    </form>
  </section>

  <?php if ($flash): ?><div class="notice"><?= e($flash) ?></div><?php endif; ?>

  <section class="metrics" aria-label="Resumo financeiro de <?= e($mesLegivel) ?>">
    <article class="metric"><span>Saldo do mês</span><strong class="<?= $saldo < 0 ? 'negative' : '' ?>"><?= dinheiro($saldo) ?></strong><small><?= e($mesLegivel) ?></small></article>
    <article class="metric"><span>Receitas</span><strong class="positive"><?= dinheiro((float)$resumo['receitas']) ?></strong><small>Dinheiro que entrou</small></article>
    <article class="metric"><span>Despesas</span><strong class="negative"><?= dinheiro((float)$resumo['despesas']) ?></strong><small>Dinheiro que saiu</small></article>
    <article class="metric"><span>Lançamentos</span><strong><?= (int)$resumo['quantidade'] ?></strong><small>No período selecionado</small></article>
  </section>

  <div class="content-grid">
    <section class="panel">
      <div class="panel-heading"><div><p class="eyebrow">MOVIMENTAÇÕES</p><h2>Lançamentos de <?= e($mesLegivel) ?></h2></div><a class="btn btn-green" href="form.php">+ Novo lançamento</a></div>
      <?php if (!$lancamentos): ?>
        <div class="empty"><div class="empty-icon">↗</div><h3>Nenhum lançamento por aqui</h3><p>Adicione sua primeira receita ou despesa para começar.</p></div>
      <?php else: ?>
      <div class="table-wrap"><table><thead><tr><th>Descrição</th><th>Categoria</th><th>Data</th><th>Valor</th><th>Ações</th></tr></thead><tbody>
      <?php foreach ($lancamentos as $l): ?>
        <tr>
          <td><div class="transaction-title"><?= e($l['descricao']) ?></div><span class="type-label <?= e($l['tipo']) ?>"><?= $l['tipo'] === 'receita' ? 'Receita' : 'Despesa' ?></span></td>
          <td><?= e($l['categoria']) ?></td><td><?= date('d/m/Y', strtotime($l['data_lancamento'])) ?></td>
          <td class="<?= $l['tipo'] === 'receita' ? 'positive' : 'negative' ?> value"><?= $l['tipo'] === 'receita' ? '+' : '−' ?> <?= dinheiro((float)$l['valor']) ?></td>
          <td><div class="actions"><a href="form.php?id=<?= (int)$l['id'] ?>">Editar</a><form method="post" action="delete.php" onsubmit="return confirm('Excluir este lançamento? Esta ação não pode ser desfeita.');"><input type="hidden" name="id" value="<?= (int)$l['id'] ?>"><button class="link-danger" type="submit">Excluir</button></form></div></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
      <?php endif; ?>
    </section>

    <aside class="panel breakdown"><p class="eyebrow">ONDE VOCÊ GASTA</p><h2>Despesas por categoria</h2>
      <?php if (!$categoriasResumo): ?><p class="muted small">Ainda não há despesas neste mês.</p>
      <?php else: foreach ($categoriasResumo as $c): $pct = (int)round(((float)$c['total'] / $maxCategoria) * 100); ?>
        <div class="bar-item"><div class="bar-label"><span><?= e($c['categoria']) ?></span><strong><?= dinheiro((float)$c['total']) ?></strong></div><div class="bar-track"><div class="bar-fill" style="width:<?= $pct ?>%"></div></div></div>
      <?php endforeach; endif; ?>
      <div class="tip"><strong>Dica Equilibra</strong><p>Revise seus gastos com frequência e compare os meses para encontrar oportunidades de economizar.</p></div>
    </aside>
  </div>
  <footer>€QUILIBRA · Organização financeira simples e consciente.</footer>
</main>
<script src="assets/app.js"></script>
</body></html>
