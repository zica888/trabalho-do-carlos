<?php
declare(strict_types=1);
$hoje = date('Y-m-d');
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Simulador de investimentos | €QUILIBRA</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="index.php"><span class="brand-symbol">€</span>QUILIBRA</a>
  <nav class="nav-links"><a href="index.php">Painel financeiro</a><a class="active" href="simulador.php">Simulador</a></nav>
</header>
<main class="container">
  <section class="welcome">
    <div><p class="eyebrow">PLANEJAMENTO FINANCEIRO</p><h1>Simule seu investimento.</h1><p class="muted">Estime o rendimento e os descontos antes de investir, com as taxas informadas por você.</p></div>
  </section>

  <div class="simulator-layout">
    <section class="panel">
      <p class="eyebrow">1 · DADOS DA APLICAÇÃO</p>
      <h2>Quanto você pretende investir?</h2>
      <form id="investment-form">
        <div class="form-grid sim-grid">
          <div class="field"><label for="capital">Capital inicial (R$) *</label><input id="capital" name="capital" type="number" min="0.01" step="0.01" value="1000" required></div>
          <div class="field"><label for="taxa">Taxa de juros (%) *</label><input id="taxa" name="taxa" type="number" min="0" step="0.01" value="1" required></div>
          <div class="field"><label for="periodicidade">A taxa informada é *</label><select id="periodicidade" name="periodicidade"><option value="mensal">Mensal</option><option value="anual">Anual</option></select></div>
          <div class="field"><label for="capitalizacao">Capitalização</label><select id="capitalizacao" name="capitalizacao"><option value="composta">Juros compostos</option><option value="simples">Juros simples</option></select></div>
          <div class="field"><label for="data_inicio">Data inicial da aplicação *</label><input id="data_inicio" name="data_inicio" type="date" value="<?= htmlspecialchars($hoje, ENT_QUOTES, 'UTF-8') ?>" required></div>
          <div class="field"><label for="tempo">Tempo aplicado (meses) *</label><input id="tempo" name="tempo" type="number" min="1" max="1200" step="1" value="12" required></div>
        </div>

        <div class="discount-heading"><p class="eyebrow">2 · DESCONTOS E IMPOSTOS</p><h2>Quais descontos se aplicam?</h2><p class="muted small">Marque somente os que se aplicam ao produto escolhido. Informe a porcentagem de cada um. Se não souber, consulte as condições do investimento.</p></div>
        <div class="discount-list">
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="ir"><span class="discount-copy"><strong>Imposto de Renda (IR)</strong><small>Percentual sobre o rendimento tributável, não sobre o capital.</small></span><span class="rate-input"><input id="ir" type="number" min="0" max="100" step="0.01" value="15" disabled><b>%</b></span></label>
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="iof"><span class="discount-copy"><strong>IOF</strong><small>Quando aplicável, normalmente incide sobre o rendimento em resgates nos primeiros 30 dias; informe a alíquota efetiva.</small></span><span class="rate-input"><input id="iof" type="number" min="0" max="100" step="0.01" value="0" disabled><b>%</b></span></label>
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="administracao"><span class="discount-copy"><strong>Taxa de administração</strong><small>Estimativa percentual sobre o capital inicial para todo o período.</small></span><span class="rate-input"><input id="administracao" type="number" min="0" max="100" step="0.01" value="0" disabled><b>%</b></span></label>
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="performance"><span class="discount-copy"><strong>Taxa de performance</strong><small>Estimativa percentual sobre o rendimento bruto positivo.</small></span><span class="rate-input"><input id="performance" type="number" min="0" max="100" step="0.01" value="0" disabled><b>%</b></span></label>
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="custodia"><span class="discount-copy"><strong>Custódia</strong><small>Estimativa percentual sobre o capital inicial para todo o período.</small></span><span class="rate-input"><input id="custodia" type="number" min="0" max="100" step="0.01" value="0" disabled><b>%</b></span></label>
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="corretagem"><span class="discount-copy"><strong>Corretagem / tarifa de operação</strong><small>Percentual estimado sobre o capital inicial.</small></span><span class="rate-input"><input id="corretagem" type="number" min="0" max="100" step="0.01" value="0" disabled><b>%</b></span></label>
          <label class="discount-row"><input type="checkbox" class="discount-toggle" data-target="outros"><span class="discount-copy"><strong>Outro desconto</strong><small>Informe tarifas ou encargos adicionais cobrados pelo produto.</small></span><span class="rate-input"><input id="outros" type="number" min="0" max="100" step="0.01" value="0" disabled><b>%</b></span></label>
        </div>
        <button class="btn btn-green calculate-btn" type="submit">Calcular retorno estimado</button>
      </form>
    </section>

    <aside class="panel result-panel" aria-live="polite">
      <p class="eyebrow">3 · RESULTADO ESTIMADO</p><h2>Resumo da aplicação</h2>
      <div class="result-main"><span>Valor líquido estimado no vencimento</span><strong id="liquido">R$ 1.126,16</strong><small id="resultado-nota">Preencha os dados e calcule a simulação.</small></div>
      <div class="result-line"><span>Capital inicial</span><strong id="r-capital">R$ 1.000,00</strong></div>
      <div class="result-line"><span>Rendimento bruto</span><strong id="r-bruto">R$ 126,83</strong></div>
      <div class="result-line"><span>Total de descontos estimados</span><strong id="r-descontos">R$ 0,00</strong></div>
      <div class="result-line"><span>Rendimento líquido</span><strong id="r-rendimento">R$ 126,16</strong></div>
      <div class="liquidity-card"><span>Data estimada de liquidez / vencimento</span><strong id="liquidez">—</strong><small>Calculada a partir da data inicial + prazo informado.</small></div>
      <div class="tip"><strong>Importante</strong><p>Esta é uma simulação educativa, não uma cotação ou recomendação. As regras variam por produto. O IR e o IOF reais podem seguir tabelas, prazos e bases de cálculo específicas; taxas fixas e percentuais foram simplificados conforme os campos informados. A data de liquidez real depende das regras do investimento e pode ser diferente da data estimada aqui.</p></div>
    </aside>
  </div>
  <footer>€QUILIBRA · Simulação educativa, não constitui recomendação de investimento.</footer>
</main>
<script src="assets/simulador.js"></script>
</body></html>
