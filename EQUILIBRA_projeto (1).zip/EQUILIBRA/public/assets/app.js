document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#entry-form');
  if (form) {
    form.addEventListener('submit', (event) => {
      const descricao = document.querySelector('#descricao');
      const valor = document.querySelector('#valor');
      const data = document.querySelector('#data_lancamento');
      if (!descricao.value.trim() || Number(valor.value) <= 0 || !data.value) {
        event.preventDefault();
        alert('Preencha a descrição, um valor maior que zero e uma data válida.');
      }
    });
    document.querySelectorAll('input[name="tipo"]').forEach((input) => {
      input.addEventListener('change', () => {
        document.querySelectorAll('.choice').forEach((choice) => choice.classList.remove('selected'));
        input.closest('.choice').classList.add('selected');
      });
    });
  }
});
