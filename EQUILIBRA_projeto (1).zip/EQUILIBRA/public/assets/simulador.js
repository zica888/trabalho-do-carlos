document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#investment-form');
  if (!form) return;
  const money = value => new Intl.NumberFormat('pt-BR', {style:'currency',currency:'BRL'}).format(value);
  const num = id => Number(document.getElementById(id).value || 0);
  const checked = id => document.querySelector(`.discount-toggle[data-target="${id}"]`).checked;

  document.querySelectorAll('.discount-toggle').forEach(toggle => {
    const field = document.getElementById(toggle.dataset.target);
    toggle.addEventListener('change', () => {
      field.disabled = !toggle.checked;
      toggle.closest('.discount-row').classList.toggle('enabled', toggle.checked);
    });
  });

  function addMonthsSafe(date, months) {
    const d = new Date(date + 'T12:00:00');
    const day = d.getDate();
    d.setDate(1);
    d.setMonth(d.getMonth() + months);
    const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(day, lastDay));
    return d;
  }
  const formatDate = d => new Intl.DateTimeFormat('pt-BR').format(d);

  function calculate(event) {
    if (event) event.preventDefault();
    const capital = num('capital');
    const rate = num('taxa') / 100;
    const months = Math.floor(num('tempo'));
    const start = document.getElementById('data_inicio').value;
    if (!(capital > 0) || rate < 0 || !(months >= 1) || !start) {
      alert('Informe capital maior que zero, taxa válida, data inicial e prazo de pelo menos um mês.');
      return;
    }
    if (months > 1200) { alert('O prazo máximo desta simulação é 1200 meses.'); return; }
    const monthlyRate = document.getElementById('periodicidade').value === 'anual'
      ? Math.pow(1 + rate, 1/12) - 1 : rate;
    const factor = document.getElementById('capitalizacao').value === 'simples'
      ? 1 + monthlyRate * months : Math.pow(1 + monthlyRate, months);
    const grossTotal = capital * factor;
    const grossProfit = Math.max(0, grossTotal - capital);
    let discounts = 0;
    const detail = [];
    // Todos os percentuais são informados pelo usuário; bases simplificadas e explicadas na interface.
    const charges = [
      ['ir', grossProfit],
      ['iof', grossProfit],
      ['administracao', capital],
      ['performance', grossProfit],
      ['custodia', capital],
      ['corretagem', capital],
      ['outros', capital]
    ];
    for (const [id, base] of charges) {
      if (checked(id)) {
        const pct = num(id);
        if (pct < 0 || pct > 100) { alert('As porcentagens de descontos devem ficar entre 0 e 100.'); return; }
        const value = base * pct / 100;
        discounts += value;
        if (pct > 0) detail.push(`${id}: ${money(value)}`);
      }
    }
    discounts = Math.min(discounts, grossTotal);
    const netTotal = Math.max(0, grossTotal - discounts);
    const netProfit = netTotal - capital;
    const liquidity = addMonthsSafe(start, months);
    document.getElementById('liquido').textContent = money(netTotal);
    document.getElementById('r-capital').textContent = money(capital);
    document.getElementById('r-bruto').textContent = money(grossProfit);
    document.getElementById('r-descontos').textContent = money(discounts);
    document.getElementById('r-rendimento').textContent = money(netProfit);
    document.getElementById('liquidez').textContent = formatDate(liquidity);
    document.getElementById('resultado-nota').textContent = netProfit >= 0
      ? `Ganho líquido estimado de ${money(netProfit)} no período.`
      : `Perda estimada de ${money(Math.abs(netProfit))} em relação ao capital inicial.`;
  }
  form.addEventListener('submit', calculate);
  document.querySelectorAll('#investment-form input, #investment-form select').forEach(el => {
    el.addEventListener('change', () => {
      // Atualiza o resultado após uma simulação inicial, sem interromper o preenchimento.
      if (document.getElementById('liquidez').textContent !== '—') calculate();
    });
  });
});
