<?php
declare(strict_types=1);

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function dinheiro(float|string $valor): string {
    return 'R$ ' . number_format((float)$valor, 2, ',', '.');
}

function categorias(): array {
    return ['Alimentação', 'Transporte', 'Moradia', 'Saúde', 'Educação', 'Lazer', 'Contas', 'Renda', 'Investimentos', 'Outros'];
}

function validarLancamento(array $dados): array {
    $erros = [];
    if (!in_array($dados['tipo'] ?? '', ['receita', 'despesa'], true)) $erros[] = 'Selecione receita ou despesa.';
    if (trim((string)($dados['descricao'] ?? '')) === '') $erros[] = 'Informe a descrição.';
    if (mb_strlen(trim((string)($dados['descricao'] ?? ''))) > 120) $erros[] = 'A descrição deve ter até 120 caracteres.';
    if (!in_array($dados['categoria'] ?? '', categorias(), true)) $erros[] = 'Selecione uma categoria válida.';
    if (!is_numeric($dados['valor'] ?? null) || (float)$dados['valor'] <= 0 || (float)$dados['valor'] > 99999999) $erros[] = 'O valor deve ser maior que zero.';
    $data = (string)($dados['data_lancamento'] ?? '');
    $d = DateTime::createFromFormat('!Y-m-d', $data);
    if (!$d || $d->format('Y-m-d') !== $data) $erros[] = 'Informe uma data válida.';
    return $erros;
}
